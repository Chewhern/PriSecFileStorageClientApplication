﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriSecFileStorageClient
{
    public static class ETLSSessionIDStorage
    {
        public static String ETLSID { get; set; }
    }
}
