﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriSecFileStorageClient
{
    class ECDH_ECDSA_Models
    {
        public String ECDSA_PK_Base64String { get; set; }
        public String ECDH_SPK_Base64String { get; set; }
        public String ID_Checker_Message { get; set; }
    }
}
