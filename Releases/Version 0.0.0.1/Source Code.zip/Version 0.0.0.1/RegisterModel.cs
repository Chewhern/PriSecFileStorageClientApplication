﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriSecFileStorageClient
{
    class RegisterModel
    {
        public String UserIDCount { get; set; }
        public String UserIDChecker { get; set; }
        public String Error { get; set; }
    }
}
