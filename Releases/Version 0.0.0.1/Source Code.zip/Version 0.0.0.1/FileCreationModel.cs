﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PriSecFileStorageClient
{
    public class FileCreationModel
    {
        public String Status { get; set; }

        public String FolderID { get; set; }

    }
}
