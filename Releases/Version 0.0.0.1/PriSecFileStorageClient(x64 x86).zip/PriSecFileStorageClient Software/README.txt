Try to run the application that resides in Application Files.
If you are having trouble to run the .exe file, then go back
to this directory and install the required components by
clicking setup

